import java.util.*;
import javax.swing.JOptionPane;

public class SignInUp {
    
    static ArrayList<User> users = new ArrayList();    
    
    public static boolean SignIn(String usrnm, String psswrd){
        int i,j;
        
        for (i=0;i<=users.size()-1;i++) {
            if (usrnm.equals(users.get(i).getUsername())){
                if (psswrd.equals(users.get(i).getPassword())){
                    return true;
                }
                else JOptionPane.showMessageDialog(null,"Check your password.","Incorrect Password!",JOptionPane.INFORMATION_MESSAGE);
                return false;
            }
        }
        JOptionPane.showMessageDialog(null,"Check your username.","Incorrect Username!",JOptionPane.INFORMATION_MESSAGE);
        return false;
    }
    
    public static void SignUp(String usrnm, String psswrd){
        users.add(new User(usrnm, psswrd));
    }
}